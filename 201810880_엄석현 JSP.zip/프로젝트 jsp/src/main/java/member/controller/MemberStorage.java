package member.controller;

import java.util.ArrayList;

import member.vo.Member;

public class MemberStorage implements ControllerInterface {
	private static ArrayList<Member> memberList = new ArrayList<Member>();

	@Override
	public boolean insert(Member member) {
		return memberList.add(member);

	}

	@Override
	public ArrayList<Member> selectAll() {
		return memberList;
	}

	@Override
	public Member selectId(String id) {
		for (Member m : memberList) {
			if (m.getId().equals(id)) {
				return m;
			}
		}
		return null;
	}

	@Override
	public int selectMember(Member member) {
		return memberList.indexOf(member);
	}

	@Override
	public boolean update(Member member) {
		int i = selectMember(member);
		if (i == -1) {
			return false;
		} else {
			memberList.set(i, member);
			return true;
		}

	}

	@Override
	public boolean delete(Member member) {
		return memberList.remove(member);
	}

}
